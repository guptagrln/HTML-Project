
//validaton for form


function  ValidateForm()
var x=document.form1.fname.value;
{
if(x == "" )
         {
           alert("First Name is required");
           return false;
		}
}



	
