/* Google Analytics Event Tracking Code for ELS.edu */

var fbLoadScript = fbLoadScript || {};

var _gaq = _gaq || [];

var AWA = {

    prevented: false,

    setAccount: function(property_id) {
        _gaq.push(['_setAccount', property_id]);
    },

    trackEvent: function(category, action, opt_label, opt_value) {
        
        if (typeof opt_value !== 'undefined') {
            _gaq.push(['_trackEvent', category, action, opt_label, opt_value]);
            return;
        }
        else if (typeof opt_label !== 'undefined') {
            _gaq.push(['_trackEvent', category, action, opt_label]);
        }
        else {
            _gaq.push(['_trackEvent', category, action]);
        }
    },
    
    delayLoading: function(e, href) {
        e.preventDefault();
        setTimeout(function() {document.location.href = href;}, 250);
    },
    
    delaySubmission: function(e, form) {
        if ( ! this.prevented)
        {
            e.preventDefault();
            this.prevented = true;
            setTimeout(function() {form.submit();}, 250);
            
            return true;
        }
        
        return false;
    }
};

// TRACKING
AWA.setAccount('UA-1623609-1');

(function (window, $) {
// MyELS Registration
$(document).on('submit', '#registrationForm', function(e) {
    if (AWA.delaySubmission(e, $(this)))
    {
        AWA.trackEvent('MyELS', 'Register');
    }
});

// MyELS Share Estimate
$(document).on('click', '#saved-estimates #share-counselor', function(e) {
    AWA.trackEvent('Save Estimate', 'Share Estimate');
});

// MyELS Start Application
$(document).on('click', '.callouts .callout.apply a', function(e) {
    AWA.trackEvent('MyELS', 'New Application', 'Start');

    AWA.delayLoading(e, $(this).attr('href'));
});
$(document).on('click', '#apply #start-application', function(e) {
    AWA.trackEvent('My Applications', 'New Application', 'Start');
    
    AWA.delayLoading(e, $(this).attr('href'));
});
$(document).on('click', '#saved-estimates .start-application', function(e) {
    AWA.trackEvent('Save Estimate', 'New Application', 'Start');
    
    AWA.delayLoading(e, $(this).attr('href'));
});

// Submit Application
$(document).on('click', '#apply.confirmation .buttons.ok', function(e) {
    AWA.trackEvent('MyELS', 'Application Submitted');
    
    AWA.delayLoading(e, $(this).attr('href'));
});

// Centers and Locations - Filter Fields
$(document).ready(function() {
    $('#location #allcountryID, #location #prgID, #location #hsngID, #location #startDate').off();
    $('#location #allcountryID, #location #prgID, #location #hsngID, #location #startDate').on('change', function(e) {
        e.stopImmediatePropagation();
        
        var country = $('#allcountryID option:selected').text();
        
        AWA.trackEvent('Centers and Locations', 'Filter Fields',
            country
            + ((country == 'United States')
                ? '|' + $('#prgID option:selected').text()
                + '|' + $('#hsngID option:selected').text()
                + '|' + $('#startDate option:selected').text()
                : ''
                )
        );
    
        AWA.delaySubmission(e, $(this).parents('form'));
    });
});

// Centers and Locations - Map Center Details
$(document).on('click', '#location #map_canvas .center-details', function(e) {
    AWA.trackEvent('Centers and Locations', 'Map Center Details', $(this).attr('href'));

    if ( ! $(this).filter('a[target$="_blank"]').length)
    {    
        AWA.delayLoading(e, jQuery(this).attr('href'));
    }
});

// Centers and Locations - List Center Details
$(document).on('click', '#location #location-list .page_link', function(e) {
    AWA.trackEvent('Centers and Locations', 'List Center Details', $(this).attr('href'));

    if ( ! $(this).filter('a[target$="_blank"]').length)
    {    
        AWA.delayLoading(e, $(this).attr('href'));
    }
});

// Centers and Locations - Territory Link
$(document).on('click', '#location #location-list a.state', function(e) {
    AWA.trackEvent('Centers and Locations', 'Territory Link', 
           $(this).parents('ul.country').attr('id') + '|' + $(this).text());
});

// Centers and Locations - Junior Programs Link
$(document).on('click', '#location a[href="../EnglishPrograms/Junior"]', function(e) {
    AWA.trackEvent('Centers and Locations', 'Junior Programs Link');
    
    AWA.delayLoading(e, $(this).attr('href'));
});

// ELS Experience - Video
$(document).on('click', '#discover .button-experience', function(e) {
    AWA.trackEvent('ELS Experience', 'Video', 'View the Experience');
});

// ELS Experience - Filter By Center
$(document).on('change', '#discover #center-filter', function(e) {
    AWA.trackEvent('ELS Experience', 'Filter By Center', $(this).find('option:selected').text());
});

// ELS Experience - Filter By Country
$(document).on('change', '#discover #country-filter', function(e) {
    AWA.trackEvent('ELS Experience', 'Filter By Country', $(this).find('option:selected').text());
});

// University Admissions
$(document).on('click', '#admissions a[href^="http"]', function(e) {
    AWA.trackEvent('University Admissions', 'Exit Link', $(this).text());

    if ( ! $(this).filter('a[target$="_blank"]').length)
    {    
        AWA.delayLoading(e, jQuery(this).attr('href'));
    }
});

// View our programs
$(document).on('click', '#discover #admissions .button-lt a', function(e) {
    AWA.trackEvent('View our Programs', $(this).text());
    
    if ( ! $(this).filter('a[target$="_blank"]').length)
    {    
        AWA.delayLoading(e, jQuery(this).attr('href'));
    }
});

// PDF Downloads -- that's where we are
$(document).on('click', 'a[href$=".pdf"]', function(e) {
    AWA.trackEvent('PDF Downloads', $(this).attr('href').split('/').pop());
});

// Share Content Functions - Email
$(document).on('click', '#share .email', function(e) {
    AWA.trackEvent('Share Page', 'Email', location.href);
});

// Share Content Functions - Print
$(document).on('click', '#share .print', function(e) {
    AWA.trackEvent('Share Page', 'Print', location.href);
});

// Language Selector
$(document).on('click', '.language a[href*="/Language"]', function(e) {
    AWA.trackEvent('Language', $(this).attr('href').split('=').pop());
    
    if ( ! $(this).filter('a[target$="_blank"]').length)
    {    
        AWA.delayLoading(e, jQuery(this).attr('href'));
    }
});

// WIDGET
// University Finder - Opened
var university_opened = false;
$(document).on('click', '#university-finder-toggle', function(e) {
    if (university_opened === false)
    {
        university_opened = true;
        var elscom = false;
        if (location.href.indexOf('els.com') !== -1) {
            // ELS.com
            AWA.setAccount('UA-8279383-1');
            elscom = true;
        }
    
        AWA.trackEvent('University Finder', 'Opened', location.href);
        
        if (elscom === true) { // Switch back
            // ELS.edu
            AWA.setAccount('UA-1623609-1');
        }
    }
});

// University Finder
$(document).on('click', '#finder.light #cal-submit', function(e) {

    var elscom = false;
    
    if (location.href.indexOf('els.com') !== -1) {
        // ELS.com
        AWA.setAccount('UA-8279383-1');
        elscom = true;
    }
    
    AWA.trackEvent('University Finder',
        $("#finder.light #findDegree option:selected").text(),
        $("#finder.light #findStudyArea option:selected").text() + 
        '|' + $("#finder.light #findMajor option:selected").text());
    
    if (elscom === true) {  // Switch back
        // ELS.edu
        AWA.setAccount('UA-1623609-1');
    }
});

// Counselor Connect - Opened
var counselor_opened = false;
$(document).on('click', '#counselor-toggle', function(e) {
    if (counselor_opened === false)
    {
        counselor_opened = true;
        var elscom = false;
        if (location.href.indexOf('els.com') !== -1) {
            // ELS.com
            AWA.setAccount('UA-8279383-1');
            elscom = true;
        }
    
        AWA.trackEvent('Counselor Connect', 'Opened', location.href);
        
        if (elscom === true) { // Switch back
            // ELS.edu
            AWA.setAccount('UA-1623609-1');
        }
    }
});

// Counselor Connect
// V1 - embedded
$(document).on('click', '#Counselorcontrol #find-counselors', function(e) {
    AWA.trackEvent('Counselor Connect',
        'Country|' + $('#Counselorcontrol #estCountryID option:selected').text(),
        $('#Counselorcontrol #estCity option:selected').text(),
        ($('#Counselorcontrol #chkboxPAT').is(':checked') ? 1 : 0));
});
// V2 - widget
$(document).on('click', '#counselor-find #cal-submit', function(e) {
    var elscom = false;
    if (location.href.indexOf('els.com') !== -1) {
        // ELS.com
        AWA.setAccount('UA-8279383-1');
        elscom = true;
    }
    
    AWA.trackEvent('Counselor Connect',
        'Country|' + $('#counselor-find #countryID option:selected').text(),
        $('#counselor-find #city option:selected').text(),
        ($('#counselor-find #prearrival').is(':checked') ? 1 : 0));
        
    if (elscom === true) { // Switch back
        // ELS.edu
        AWA.setAccount('UA-1623609-1');
    }
});

// Cost Calculator - Opened
var calculator_opened = false;
$(document).on('click', '#calculator-toggle', function(e) {
    if (calculator_opened === false)
    {
        calculator_opened = true;
        var elscom = false;
        if (location.href.indexOf('els.com') !== -1) {
            // ELS.com
            AWA.setAccount('UA-8279383-1');
            elscom = true;
        }
    
        AWA.trackEvent('Cost Calculator', 'Opened', location.href);
        
        if (elscom === true) { // Switch back
            // ELS.edu
            AWA.setAccount('UA-1623609-1');
        }
    }
});

// Cost Calculator - Estimate Cost
$(document).on('click', '.calculator-content #cal-submit', function(e) {

    var elscom = false;
    if (location.href.indexOf('els.com') !== -1) {
        // ELS.com
        AWA.setAccount('UA-8279383-1');
        elscom = true;
    }
    
    AWA.trackEvent('Cost Calculator',
        $('#calLocations option:selected').text() +
            '|' + $('#calPrograms option:selected').text(),
        $('#calHousing option:selected').text(),
        parseInt($('#calSessions option:selected').val()), 10);
        
    if (elscom === true) { // Switch back
        // ELS.edu
        AWA.setAccount('UA-1623609-1');
    }
});

// Cost Calculator Save Estimate
$(document).on('click', '#save-estimate', function(e) {
    AWA.trackEvent('Cost Calculator', 'Save Estimate');
});
})(window, jQuery);