﻿(function (window, $) {
    window.newslist = window.newslist || {};
    newslist.apiUrl = "/api/sitecore/newsdata/";
    newslist.isInitialized = false;
    newslist.init = function () {
        initNewsList();
    };

    function initNewsList() {
        if (!newslist.isInitialized) {
            newslist.isInitialized = true;

            $("div.news-list").each(function () {
                var Container = $(this);
                var PageSize = parseInt(Container.attr("data-page-size"));
                var TemplateId = Container.attr("data-sitecore-template-id");
                var BucketTemplateId = Container.attr("data-sitecore-bucket-template-id");
                var Total = parseInt(Container.attr("data-total"));

                if (Total <= PageSize) {
                    $(".pager a.next", Container).addClass("hidden");
                }

                $(".pager a", Container).on("click", function (e) {
                    if (!$(this).hasClass("hidden")) {
                        e.preventDefault();
                        e.stopPropagation();

                        var CurrentIndex = parseInt(Container.attr("data-index"));
                        var Direction = $(this).hasClass("next") ? 1 : -1;

                        $.get(newslist.apiUrl + "GetNewsPage",
                            { PageSize: PageSize, StartIndex: (CurrentIndex + Direction) * PageSize, TemplateId: TemplateId, bucketId: BucketTemplateId },
                            function (data, status) {
                                if (status == "success") {
                                    CurrentIndex = CurrentIndex + Direction;
                                    Container.attr("data-index", CurrentIndex);
                                    html = "";
                                    for (var i = 0; i < data.length; i++) {
                                        article = data[i];
                                        html += "<div class='about-list-item'>";
                                        html += "<div class='about-list-item-detail'>";
                                        html += "<div class='about-list-item-heading'>";
                                        html += "<a href='" + article.Url + "'>" + article.NewsTitle + "</a>";
                                        html += "</div>";
                                        if (article.NewsSummary != "") {
                                            html += "<div class='about-list-item-description'>" + article.NewsSummary + "</div>";
                                        }
                                        NewsDate = GetDate(article.NewsDate);
                                        html += "<div class='label label-info'>" + GetFormatedDate(NewsDate) + "</div>";
                                        html += "</div>";
                                        html += "</div>";


                                        //html += "<li class='media'>";

                                        //if (article.NewImage != "") {
                                        //    html += "<div class='media-left'><a href='" + article.Url + "'><img src='" + article.NewsImage + "' alt='" + article.NewsImageAlt + "' /></a></div>";
                                        //}
                                        
                                        //html += "<div class='media-body'><div class='label label-info'>" + GetFormatedDate(NewsDate) + "</div><h3 class='media-title'><a href='" +
                                        //    article.Url + "'>" + article.NewsTitle + "</a></h3>";

                                        //if (article.NewsSummary != "") {
                                        //    html += "<div class='summary'>" + article.NewsSummary + "</div>";
                                        //}
                                        //html += "</li>";
                                    }
                                    $("> div.news-list-container", Container).html(html);
                                    prev = (CurrentIndex - 1) * PageSize;
                                    next = (CurrentIndex + 1) * PageSize;

                                    if (prev >= 0)
                                        $(".pager a.prev", Container).removeClass("hidden");
                                    else
                                        $(".pager a.prev", Container).addClass("hidden");


                                    if (next < Total)
                                        $(".pager a.next", Container).removeClass("hidden");
                                    else
                                        $(".pager a.next", Container).addClass("hidden");

                                    $("html, body").animate({ scrollTop: $("section#subNavSection").offset().top }, 200);
                                }
                            });
                    }
                });
            });
        }
    }

    var reISO = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2}(?:\.\d*))(?:Z|(\+|-)([\d|:]*))?$/;
    var reMsAjax = /^\/Date\((d|-|.*)\)[\/|\\]$/;
    var Months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

    function GetDate(MessedUpStupidJSONDateThatIsCompletelyUselessButIsProbablyTechincallyCorrect_Date) {
        if (typeof MessedUpStupidJSONDateThatIsCompletelyUselessButIsProbablyTechincallyCorrect_Date === 'string') {
            var a = reISO.exec(MessedUpStupidJSONDateThatIsCompletelyUselessButIsProbablyTechincallyCorrect_Date);
            if (a)
                return new Date(MessedUpStupidJSONDateThatIsCompletelyUselessButIsProbablyTechincallyCorrect_Date);
            a = reMsAjax.exec(MessedUpStupidJSONDateThatIsCompletelyUselessButIsProbablyTechincallyCorrect_Date);
            if (a) {
                var b = a[1].split(/[-+,.]/);
                return new Date(b[0] ? +b[0] : 0 - +b[1]);
            }
        }
        return MessedUpStupidJSONDateThatIsCompletelyUselessButIsProbablyTechincallyCorrect_Date;
    }

    function GetFormatedDate(Date) {        
        return Months[Date.getMonth()] + " " + Date.getDate() + ", " + Date.getFullYear();
    }

    $(document).ready(function () {
        initNewsList();
    });
})(window, jQuery);