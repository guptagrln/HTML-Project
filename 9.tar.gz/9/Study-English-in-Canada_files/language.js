﻿//jQuery("#languagesearch").keyup(function (event) {
//    if (event.keyCode == 13) {
//        onLanguageCountryChange(event);
//    }
//    else {
//        var searchString = jQuery('#languagesearch').val();
//        var url = "/api/Sitecore/LanguageSelector/PerformSearch";

//        jQuery.get(url,
//            { input: searchString },
//            function (data) {
//                availOptions = new Array();
//                jQuery.each(data, function (index, item) {
//                    var option = item.CountryName + ", " + item.CountryCode;
//                    availOptions.push(option);
//                });
//                window.languageModule.init()
//            });
//    }
//});

(function (window, $) {
    "use strict";

    window.languageModule = window.languageModule || {};

    window.languageModule.init = function () {
        initLanguage();
    };

    window.languageModule.element = $('#languageSelection');
    //window.languageModule.centerAutocomplete = $('#languagesearch', window.languageModule.element);
    window.languageModule.element.on('change', onLanguageCountryChange);

    $("#language-toggle").on('click', function (e) {
        e.preventDefault();
        if ($('#language-selector').hasClass('hide')) {
            $('#language-selector').removeClass('hide');
        }
        else {
            $('#language-selector').addClass('hide');
        }
    })
    //function initLanguage() {

    //    //requires jquery ui 
    //    if (window.languageModule.centerAutocomplete.length) {
    //        var widget = window.languageModule.centerAutocomplete.autocomplete({

    //            //source: availOptions,
    //            source: function (request, response) {
    //                // delegate back to autocomplete, but extract the last term
    //                response($.ui.autocomplete.filter(
    //                availOptions, ""));
    //            },
    //            autoFocus: true,

    //            minLength: 0,

    //            select: function (event, ui) {
    //                $(this).val(ui.item.label);
    //                onLanguageCountryChange(event);
    //                return false;
    //            }
    //        }).data('ui-autocomplete');

    //        widget._renderMenu = function (ul, items) {
    //            var that = this;
    //            $.each(items, function (index, item) {
    //                that._renderItemData(ul, item);
    //            });

    //            $(ul).addClass("ui-autocompletelist");
    //            $(ul).find("li").addClass("header-navigation-utility-selector-list-item");
    //        };
    //    }
    //}

    function onLanguageCountryChange(e) {
        var selectedOption = jQuery(window.languageModule.element).val();
        //alert(selectedOption);
        //var country = jQuery.trim(selectedOption.substring(0, selectedOption.indexOf(',')));
        //var language = jQuery.trim(selectedOption.substring(selectedOption.indexOf(',') + 1));
        var country = "";
        var language = selectedOption;
        var host = window.location.host;
        var currentUrl = window.location.href;
        var protocol = window.location.protocol + "//";

        if (selectedOption != "") {
            jQuery.ajax({
                url: window.location.href,
                type: "POST",
                context: this,
                data: { scController: "LanguageSelector", scAction: "SetSelection", language: language, country: country },
                success: function (data) {
                    //jQuery('#languagesearch').val('CULTURE_COOKIE');
                    currentUrl = protocol + host + data;

                    if (data != "")
                        window.location = data;
                },
                error: function (data) {
                    console.log("error", data);
                }
            });
        }
    }

    //$(window.document).ready(function () {
    //    jQuery.ajax({
    //        url: "/api/Sitecore/LanguageSelector/GetLang",
    //        type: "GET",
    //        success: function (data) {
    //            jQuery.each(data, function (index, item) {
    //                jQuery('#defaultSelection').html('<strong>' + item.Key + ', </strong>' + item.Value);
    //            });
    //        },
    //        error: function (data) {
    //            console.log("error", data);
    //        }
    //    });
    //});
})(window, jQuery);